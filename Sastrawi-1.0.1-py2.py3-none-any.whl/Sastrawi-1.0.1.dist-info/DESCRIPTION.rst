Library for stemming Indonesian (Bahasa) text


